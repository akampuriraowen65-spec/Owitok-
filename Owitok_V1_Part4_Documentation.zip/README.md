# Owitok V1

Owitok is a fresh short-video social app foundation.

## Included now
- Dark TikTok-style vertical video feed
- Following / For You tabs
- Local video upload and playback
- Local video storage with IndexedDB
- Create/upload screen
- Basic editor tool foundation
- Search/discover interface
- Profile
- Likes/saves/comments stored locally
- Inbox interface
- Settings
- PWA manifest/service worker
- Responsive mobile-first design
- Owitok branding and gradient visual system

## Important
This V1 intentionally does not invent real followers, views, accounts, or global comments. Social data becomes real after the backend/database stage.

## GitHub Pages
Upload the files to a GitHub repository and enable:
Settings -> Pages -> Deploy from branch -> main -> / (root)

## Next engineering stage
Connect authentication, database, object/media storage, global search, real accounts, followers, comments, notifications, messaging, and server-side video processing.

The interface is designed so those backend features can be connected without throwing away the V1 screens.
